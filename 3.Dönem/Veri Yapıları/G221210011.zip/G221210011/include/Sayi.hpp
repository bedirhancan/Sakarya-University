// sayi.hpp

#ifndef Sayi_hpp
#define Sayi_hpp

#include "Basamak.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
using namespace std;


class Sayi {
public:
    Basamak* basamaklar;
    Basamak* head;
   Sayi();
   ~Sayi();
    friend std::ostream& operator<<(std::ostream& os, const Sayi& sayi);
    int karsilastir(const Sayi& digerSayi) const;
    void ekleBasamak(int deger);
    void yazdir();
     void tekDegerTutananlariBasaAl();
     void basamaklariTersCevir(); 
     void enBuyukSayiyiCikar();
    void OkuSayi(string sayiStr);

private:
    Basamak* sonBasamagiBul();
};

#endif // SAYI_HPP
