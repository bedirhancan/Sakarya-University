#ifndef SayilarListesi_hpp
#define SayilarListesi_hpp

#include "Dugum.hpp"
#include "Basamak.hpp"
#include "Sayi.hpp"

#include <iostream>
using namespace std;

class SayilarListesi {
public:
    Basamak* basamaklar;
    SayilarListesi(); 
    ~SayilarListesi();
    void yazdir();
    void tumSayilariYazdir()const;
    void ekleSayi(Sayi* sayi);
    // void tekDegerTutananlariBasaAl();
    // void basamaklariTersCevir();
    void enBuyukSayiyiCikar();
    //Dugum* enBuyukSayiyiBul();
     Dugum* baslangic;
    Dugum* head; 
};

#endif // SAYILARLISTESI_HPP