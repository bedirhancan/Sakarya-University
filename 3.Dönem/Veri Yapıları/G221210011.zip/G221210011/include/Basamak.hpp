#ifndef Basamak_hpp
#define Basamak_hpp
 

#include <iostream>

class Basamak {
public:
    int deger;
    Basamak* next;
    Basamak(int deger ,Basamak* next = nullptr);
     friend std::ostream& operator<<(std::ostream& os, const Basamak& basamak);
};

#endif // BASAMAK_HPP
