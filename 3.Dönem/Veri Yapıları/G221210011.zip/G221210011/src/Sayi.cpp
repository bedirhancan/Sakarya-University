/*
* @file Dosya adı  :Sayi.cpp
* @description Programınızın açıklaması ne yaptığına dair.
* @course Dersi aldığınız eğitim türü ve grup : 2-A  G221210011
* @assignment Kaçıncı ödev olduğu : ödev1
* @date Kodu oluşturduğunuz Tarih :25.11.2023
* @author Gruptakilerin yazar adları ve mail adresleri : Zeynep Dilara Kurnaz zeynep.kurnaz@ogr.sakarya.edu.tr 
*/

#include "Sayi.hpp"

Sayi::Sayi() : basamaklar(nullptr) , head(nullptr) {}

// int Sayi::karsilastir(const Sayi& digerSayi) const {
//     // İki sayıyı karşılaştırma mantığını burada uygulayın
//     // Örneğin, basamakları karşılaştırabilir ve ilk farklı basamağı bulabilirsiniz
//     // Daha karmaşık bir mantık gerekiyorsa, uygun şekilde uyarlayabilirsiniz
//     // Örneğin, sayıları bir tam sayı olarak dönüştürüp karşılaştırabilirsiniz
// }

Sayi::~Sayi() {
    while (basamaklar != nullptr) {
        Basamak* silinecek = basamaklar;
        basamaklar = basamaklar->next;
        delete silinecek;
    }
}
int Sayi::karsilastir(const Sayi& digerSayi) const {
//     // İki sayıyı karşılaştırma mantığını burada uygulayın
//     // Örneğin, basamakları karşılaştırabilir ve ilk farklı basamağı bulabilirsiniz
//     // Daha karmaşık bir mantık gerekiyorsa, uygun şekilde uyarlayabilirsiniz
//     // Örneğin, sayıları bir tam sayı olarak dönüştürüp karşılaştırabilirsiniz
//     // ...
//     return 0; // Örnek olarak, şu an her zaman eşit olduğunu farz ediyoruz
}



// void Sayi::ekleBasamak(int deger) {
//     Basamak* yeniBasamak = new Basamak(deger);
//     yeniBasamak->next = basamaklar;
//     basamaklar = yeniBasamak;
// }
	void Sayi::ekleBasamak(int deger) {
        Basamak* yeniBasamak = new Basamak(deger);
        if (!basamaklar) {
            basamaklar = yeniBasamak;
        } 
        else {
            Basamak* temp = basamaklar;
            while (temp->next) {
                temp = temp->next;
            }
            temp->next = yeniBasamak;
        }
    }
	
  void Sayi::OkuSayi(string sayiStr) {
    for (char c : sayiStr) {
        if (c >= '0' && c <= '9') {
            int deger = c - '0'; 
            Sayi::ekleBasamak(deger);
        }
        
    }
    std::cout<<endl;
	}

void Sayi::yazdir() {
    for (Basamak* iter = basamaklar; iter != nullptr; iter = iter->next) {
        std::cout << iter->deger << " ";
    }
    std::cout << std::endl;
}

void Sayi::tekDegerTutananlariBasaAl() {
    if (basamaklar == nullptr || basamaklar->next == nullptr) {
        // Listede 0 veya 1 eleman varsa işlem yapma
        return;
    }

    // Başa alma işlemi için geçici bir liste oluştur
    Basamak* tekDegerliBasamaklar = nullptr;

    // Tek değerli basamakları geçici listeye ekle
    Basamak* current = basamaklar;
    while (current != nullptr) {
        if (current->deger % 2 == 1) {
            // Tek değerli basamakları geçici listeye ekle
            Basamak* temp = current;
            current = current->next;
            temp->next = tekDegerliBasamaklar;
            tekDegerliBasamaklar = temp;
        } else {
            current = current->next;
        }
}


    // Kalan basamakları geçici listeye ekle
    current = basamaklar;
    while (current != nullptr) {
        if (current->deger % 2 == 0) {
            // Çift değerli basamakları geçici listeye ekle
            Basamak* temp = current;
            current = current->next;
            temp->next = tekDegerliBasamaklar;
            tekDegerliBasamaklar = temp;
        } else {
            current = current->next;
        }
    }

    // Geçici listeyi başa alma işlemi tamamlanmış haliyle orijinal listeye kopyala
    basamaklar = tekDegerliBasamaklar;
}

// void Sayi::tekDegerTutananlariBasaAl() {
//     if (basamaklar == nullptr || basamaklar->next == nullptr) {
//         // Listede 0 veya 1 eleman varsa işlem yapma
//         return;
//     }

//     // Tek değerli basamakları başa alma işlemi için geçici bir liste oluştur
//     Basamak* simdiki = basamaklar;
//     Basamak* basaAlinanSonTek = nullptr;

//     while (simdiki != nullptr) {
//         Basamak* sonraki = simdiki->next;

//         // Tek değer tutan basamakları başa al
//         if (simdiki->deger % 2 == 1) {
//             // Başta olan tek değer tutan basamak
//             basaAlinanSonTek = simdiki;
//             basamaklar = sonraki;
            
//             // Başa alınan tek değer tutan basamak
//             basaAlinanSonTek->next = basamaklar;
//             basamaklar = basaAlinanSonTek;
//         }

//         simdiki = sonraki;
//     }
// }

   
   void Sayi::basamaklariTersCevir() {
    if (basamaklar == nullptr || basamaklar->next == nullptr) {
        // Listede 0 veya 1 eleman varsa işlem yapma
        return;
    }

    Basamak* simdiki = basamaklar;
    Basamak* sonraki = nullptr;

    while (simdiki != nullptr) {
        sonraki = simdiki->next;
        simdiki->next = sonraki->next; // next işaretçisini bir sonraki düğümün next'ine bağla
        sonraki->next = basamaklar;    // bir sonraki düğümü listenin başına bağla
        basamaklar = sonraki;          // sonraki düğümü yeni baş olarak belirle
    }
}






std::ostream& operator<<(std::ostream& os, const Sayi& sayi) {
    Basamak* current = sayi.head;
    while (current != nullptr) {
        os << *(current);
        current = current->next;
    }
    return os;
}

Basamak* Sayi::sonBasamagiBul() {
    Basamak* sonBasamak = basamaklar;
    while (sonBasamak != nullptr && sonBasamak->next != nullptr) {
        sonBasamak = sonBasamak->next;
    }
    return sonBasamak;
}



