/*
* @file Dosya adı  :SayilarListesi.cpp
* @description Programınızın açıklaması ne yaptığına dair.
* @course Dersi aldığınız eğitim türü ve grup : 2-A  G221210011
* @assignment Kaçıncı ödev olduğu : ödev1
* @date Kodu oluşturduğunuz Tarih :25.11.2023
* @author Gruptakilerin yazar adları ve mail adresleri : Zeynep Dilara Kurnaz zeynep.kurnaz@ogr.sakarya.edu.tr 
*/
#include "SayilarListesi.hpp"

SayilarListesi::SayilarListesi() : head(nullptr) {}

SayilarListesi::~SayilarListesi() {
    Dugum* current = head;
    while (current != nullptr) {
        Dugum* next = current->sonraki;
        delete current;
        current = next;
    }
}

void SayilarListesi::yazdir() {
    for (Basamak* iter = basamaklar; iter != nullptr; iter = iter->next) {
        std::cout << iter->deger << " "<<iter->next;
    }
    std::cout << std::endl;
}
void SayilarListesi::ekleSayi(Sayi* sayi){
    Dugum* yeniDugum=new Dugum(sayi);
    yeniDugum->sonraki=head;
    head=yeniDugum;
}


void SayilarListesi::tumSayilariYazdir() const {
   Dugum* currentDugum = head;

    while (currentDugum != nullptr) {
        Sayi* currentSayi = currentDugum->sayi;
        currentSayi->yazdir();
        currentDugum = currentDugum->sonraki;
        std::cout <<"\n";
    }
}

void SayilarListesi::enBuyukSayiyiCikar() {
    if (head == nullptr) {
        std::cout << "Liste bos, en buyuk sayi cikartilamaz.\n";
        return;
    }

    Dugum* enBuyukPrev = nullptr;
    Dugum* enBuyuk = head;
    Dugum* current = head->sonraki;

    while (current != nullptr) {
        if (current->sayi->karsilastir(*enBuyuk->sayi) > 0) {
            enBuyuk = current;
            enBuyukPrev = nullptr;  // enBuyuk değiştiğinde enBuyukPrev'i sıfırla
        } else {
            enBuyukPrev = current;
        }
        current = current->sonraki;
    }

    if (enBuyukPrev == nullptr) {
        // En büyük sayı listenin başında
        head = head->sonraki;
    } else {
        enBuyukPrev->sonraki = enBuyuk->sonraki;
    }

    std::cout << "En buyuk sayi cikarildi: " << *(enBuyuk->sayi) << "\n";
    delete enBuyuk;
}
