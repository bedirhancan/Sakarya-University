/*
* @file Dosya adı  :Dugum.cpp
* @description Programınızın açıklaması ne yaptığına dair.
* @course Dersi aldığınız eğitim türü ve grup : 2-A  G221210011
* @assignment Kaçıncı ödev olduğu : ödev1
* @date Kodu oluşturduğunuz Tarih :25.11.2023
* @author Gruptakilerin yazar adları ve mail adresleri : Zeynep Dilara Kurnaz zeynep.kurnaz@ogr.sakarya.edu.tr 
*/
#include "Dugum.hpp"

Dugum::Dugum(Sayi* sayi, Dugum* sonraki) : sayi(sayi), sonraki(sonraki) {}
