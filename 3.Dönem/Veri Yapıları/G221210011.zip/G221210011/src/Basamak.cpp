/*
* @file Dosya adı  :Basamak.cpp
* @description Programınızın açıklaması ne yaptığına dair.
* @course Dersi aldığınız eğitim türü ve grup : 2-A  G221210011
* @assignment Kaçıncı ödev olduğu : ödev1
* @date Kodu oluşturduğunuz Tarih :25.11.2023
* @author Gruptakilerin yazar adları ve mail adresleri : Zeynep Dilara Kurnaz zeynep.kurnaz@ogr.sakarya.edu.tr 
*/
#include "Basamak.hpp"

Basamak::Basamak(int deger, Basamak* next) : deger(deger), next(next) {}

std::ostream& operator<<(std::ostream& os, const Basamak& basamak) {
    os << basamak.deger;
    return os;
}
