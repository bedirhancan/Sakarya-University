/*
* @file Dosya adı  :Main.cpp
* @description Programınızın açıklaması ne yaptığına dair.
* @course Dersi aldığınız eğitim türü ve grup : 2-A  G221210011
* @assignment Kaçıncı ödev olduğu : ödev1
* @date Kodu oluşturduğunuz Tarih :25.11.2023
* @author Gruptakilerin yazar adları ve mail adresleri : Zeynep Dilara Kurnaz zeynep.kurnaz@ogr.sakarya.edu.tr 
*/
#include <iostream>
#include "SayilarListesi.hpp"
#include "Sayi.hpp"
#include "Basamak.hpp"
#include "Dugum.hpp"
#include <fstream>
#include <sstream>
 Sayi sayii;
SayilarListesi sayilarListesi;
 void cikti(){ Basamak* basamak = sayii.basamaklar;
    while (basamak) {
        cout << basamak->deger << " Adres: ("<<basamak<<")";
        basamak = basamak->next;
        cout << endl;
    }
    cout << endl;
}
int main(int argc, char* argv[]) {
   
   
    ifstream dosya("./Sayilar.txt");
    if (dosya.is_open()) {
        string satir;
        while (getline(dosya, satir)) {
            cout << satir << endl;
            sayii.OkuSayi(satir);
        }
        dosya.close();
    } else {
        cerr << "Dosya acma hatasi!" << endl;
        return 1;
    }  
    // SayilarListesi'ni ekrana yazdır
    sayilarListesi.tumSayilariYazdir();

    cikti();

    int secim;
    do {
        std::cout << "1. Tek Deger Tutanlari Basa Al\n"
                     "2. Basamaklari Ters Cevir\n"
                     "3. En Buyuk Sayiyi Cikar\n"
                     "4. Cikis\n"
                     "Seciminiz: ";
        std::cin >> secim;

        switch (secim) {
            case 1:
                sayii.tekDegerTutananlariBasaAl();
                cikti();
                break;
            case 2:
                sayii.basamaklariTersCevir();
                cikti();
                break;
            case 3:
                sayilarListesi.enBuyukSayiyiCikar();
                cikti();
                break;
            case 4:
                std::cout << "Program sonlandiriliyor.\n";
                system("pause");
                break;
            default:
                std::cout << "Geçersiz secim. Tekrar deneyin.\n";
                break;
        }

    } while (secim != 4);
    system("pause");

    return 0;
}
